package com.myerp.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myerp.entity.DeptDto;
import com.myerp.entity.DeptId;

public interface DeptRepository extends JpaRepository<DeptDto, DeptId> {

	/**
	 * 부서 조회
	 */
	Optional<DeptDto> findByDgubunAndDcode(String dgubun, int dcode);
}
